import 'package:eatwiseapp/auth/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'family_register_page.dart';
import 'login_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final authService = AuthService();
  final supabase = Supabase.instance.client;

  String name = '';
  String email = '';
  String role = '';

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  void _loadProfileData() {
    final user = supabase.auth.currentUser;

    setState(() {
      email = user?.email ?? '';
      name = user?.userMetadata?['first_name'] ?? 'User';
      role = user?.userMetadata?['role'] ?? 'user';
    });
  }

  void _logout() async {
    await authService.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  void _goToFamilyRegister() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const FamilyRegisterPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Profile",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF0F9D58),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: _logout,
            icon: Icon(
              Icons.logout,
              color: Color.fromARGB(
                128,
                255,
                255,
                255,
              ), // semi-transparent white
            ),
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome, $name",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text("Email: $email"),
            const SizedBox(height: 4),
            Text("Role: $role"),
            const SizedBox(height: 30),
            if (role == 'user')
              ElevatedButton(
                onPressed: _goToFamilyRegister,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0F9D58),
                ),
                child: const Text(
                  "Register Family",
                  style: TextStyle(color: Colors.white),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
