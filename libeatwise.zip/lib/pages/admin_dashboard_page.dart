import 'package:eatwiseapp/pages/login_page.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  final supabase = Supabase.instance.client;

  List<Map<String, dynamic>> posts = [];
  List<Map<String, dynamic>> users = [];

  final _postTitleController = TextEditingController();
  final _postContentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    print("Current Admin: ${supabase.auth.currentUser?.email}");
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      print("Fetching posts and users...");
      final postsResponse = await supabase
          .from('posts')
          .select()
          .order('created_at');
      final usersResponse = await supabase
          .from('users')
          .select()
          .order('created_at');

      print("Posts loaded: ${postsResponse.length}");
      print("Users loaded: ${usersResponse.length}");

      setState(() {
        posts = List<Map<String, dynamic>>.from(postsResponse);
        users = List<Map<String, dynamic>>.from(usersResponse);
      });
    } catch (e) {
      print("Error fetching data: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error loading data: $e")));
    }
  }

  Future<void> addPost() async {
    final title = _postTitleController.text.trim();
    final content = _postContentController.text.trim();
    if (title.isEmpty || content.isEmpty) return;

    try {
      await supabase.from('posts').insert({'title': title, 'content': content});
      _postTitleController.clear();
      _postContentController.clear();
      fetchData();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Failed to add post: $e")));
    }
  }

  Future<void> deletePost(String id) async {
    try {
      await supabase.from('posts').delete().eq('id', id);
      fetchData();
    } catch (e) {
      print("Failed to delete post: $e");
    }
  }

  Future<void> deleteUser(String id) async {
    try {
      await supabase.from('users').delete().eq('id', id);
      fetchData();
    } catch (e) {
      print("Failed to delete user: $e");
    }
  }

  void editUserDialog(Map<String, dynamic> user) {
    final firstNameController = TextEditingController(text: user['first_name']);
    final lastNameController = TextEditingController(text: user['last_name']);
    final roleController = TextEditingController(text: user['role']);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Edit User"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: firstNameController,
              decoration: const InputDecoration(labelText: "First Name"),
            ),
            TextField(
              controller: lastNameController,
              decoration: const InputDecoration(labelText: "Last Name"),
            ),
            TextField(
              controller: roleController,
              decoration: const InputDecoration(labelText: "Role"),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              try {
                await supabase
                    .from('users')
                    .update({
                      'first_name': firstNameController.text.trim(),
                      'last_name': lastNameController.text.trim(),
                      'role': roleController.text.trim(),
                    })
                    .eq('id', user['id']);

                Navigator.pop(context);
                fetchData();
              } catch (e) {
                print(" Failed to update user: $e");
              }
            },
            child: const Text("Save"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
        ],
      ),
    );
  }

  void _logout() async {
    await supabase.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  Widget _buildPostSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          " Posts",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _postTitleController,
          decoration: const InputDecoration(labelText: "Title"),
        ),
        TextField(
          controller: _postContentController,
          decoration: const InputDecoration(labelText: "Content"),
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: addPost,
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          child: const Text("Add Post", style: TextStyle(color: Colors.white)),
        ),
        const Divider(),
        ...posts.map(
          (post) => ListTile(
            title: Text(post['title']),
            subtitle: Text(post['content']),
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => deletePost(post['id']),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUserSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          " Users",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        ...users.map(
          (user) => ListTile(
            title: Text("${user['first_name']} ${user['last_name']}"),
            subtitle: Text("${user['email']} (${user['role']})"),
            trailing: Wrap(
              spacing: 10,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.orange),
                  onPressed: () => editUserDialog(user),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => deleteUser(user['id']),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Admin Dashboard",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF0F9D58),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.logout, color: Colors.white),
          onPressed: _logout,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPostSection(),
            const Divider(thickness: 2),
            _buildUserSection(),
          ],
        ),
      ),
    );
  }
}
