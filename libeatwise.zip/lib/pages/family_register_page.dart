import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FamilyRegisterPage extends StatefulWidget {
  const FamilyRegisterPage({super.key});

  @override
  State<FamilyRegisterPage> createState() => _FamilyRegisterPageState();
}

class _FamilyRegisterPageState extends State<FamilyRegisterPage> {
  final supabase = Supabase.instance.client;

  final _groupNameController = TextEditingController();
  final _adminNameController = TextEditingController();
  final _relationshipController = TextEditingController();
  final _adminEmailController = TextEditingController();

  List<Map<String, dynamic>> members = [];

  void _addMemberField() {
    setState(() {
      members.add({'name': '', 'age': '', 'email': ''});
    });
  }

  void _removeMemberField(int index) {
    setState(() {
      members.removeAt(index);
    });
  }

  Future<void> _submit() async {
    final groupName = _groupNameController.text.trim();
    final adminName = _adminNameController.text.trim();
    final relationship = _relationshipController.text.trim();
    final adminEmail = _adminEmailController.text.trim();
    final userId = supabase.auth.currentUser?.id;

    if (groupName.isEmpty ||
        adminName.isEmpty ||
        relationship.isEmpty ||
        adminEmail.isEmpty ||
        userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all required fields')),
      );
      return;
    }

    try {
      final familyInsert = await supabase
          .from('families')
          .insert({
            'group_name': groupName,
            'admin_user_id': userId,
            'admin_name': adminName,
            'relationship': relationship,
            'email': adminEmail,
          })
          .select()
          .single();

      final familyId = familyInsert['id'];

      for (var member in members) {
        await supabase.from('family_members').insert({
          'family_id': familyId,
          'name': member['name'],
          'age': int.tryParse(member['age'] ?? '0'),
          'email': member['email'],
        });
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Family registered successfully!')),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  Widget _buildMemberForm(int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Member ${index + 1}",
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        TextField(
          decoration: const InputDecoration(labelText: "Name"),
          onChanged: (value) => members[index]['name'] = value,
        ),
        TextField(
          decoration: const InputDecoration(labelText: "Age"),
          keyboardType: TextInputType.number,
          onChanged: (value) => members[index]['age'] = value,
        ),
        TextField(
          decoration: const InputDecoration(labelText: "Email"),
          onChanged: (value) => members[index]['email'] = value,
        ),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: () => _removeMemberField(index),
            child: const Text("Remove", style: TextStyle(color: Colors.red)),
          ),
        ),
        const Divider(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Register Family"),
        backgroundColor: const Color(0xFF0F9D58),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _groupNameController,
              decoration: const InputDecoration(labelText: "Group Name"),
            ),
            TextField(
              controller: _adminNameController,
              decoration: const InputDecoration(labelText: "Your Name"),
            ),
            TextField(
              controller: _relationshipController,
              decoration: const InputDecoration(labelText: "Your Relationship"),
            ),
            TextField(
              controller: _adminEmailController,
              decoration: const InputDecoration(labelText: "Your Email"),
            ),
            const SizedBox(height: 20),
            const Text(
              "Family Members",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...List.generate(members.length, _buildMemberForm),
            TextButton.icon(
              onPressed: _addMemberField,
              icon: const Icon(Icons.add),
              label: const Text("Add Member"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F9D58),
              ),
              child: const Text("Submit Family"),
            ),
          ],
        ),
      ),
    );
  }
}
